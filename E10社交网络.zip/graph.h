#include<iostream>
#include<limits>
using namespace std;

typedef int Weight;
typedef int Vertex;
const Weight infinity = 0x3f3f3f3f;
template<class Weight,int graphsize>
class Graph{
public:
	void setdistance(Vertex source,Weight distance[],Vertex lastvertex[] )const;				   //��source�����������·��
protected:
	int count;
	Weight adjacency[graphsize][graphsize];		  //�ڽӾ���洢��ϵ

};
template<class Weight,int graphsize>
void Graph<Weight,graphsize>::setdistance(Vertex source,Weight distance[], Vertex lastvertex[]) const
{
	Vertex v, w;
	bool found[graphsize];
	for (v = 0; v < count; v++)
	{
		found[v] = false;
		distance[v] = adjacency[source][v];
		lastvertex[v] = source;
	}
	found[source] = true;
	distance[source] = 0;
	for (int i = 0; i < count; i++)
	{
		Weight min = infinity;				 //��ʼ��Ϊ�����
		for (w = 0; w < count; w++)
		{
			if (!found[w]&&distance[w] < min)
			{
				min = distance[w];
				v = w;
			}
		}
		found[v] = true;
		for (w = 0; w < count; w++)
		{
			if (!found[w] && distance[w] > min + adjacency[v][w])
			{
				distance[w] = min + adjacency[v][w];
				lastvertex[w] = v;
			}
		}
	}
}

