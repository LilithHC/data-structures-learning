#include"graph.h"
#include<string>
#include<stack>
#include<iostream>
#include<map>

using namespace std;
typedef int Weight;
typedef int Vertex;
struct node
{
	string name; int age; int id;
	node() {}
	node(string a, int b = -1, int idd = -1) :name(a), age(b), id(idd) {}
};
template<class Weight, int graphsize>
class Socialgraph 	:public Graph<Weight,graphsize>
{
public:
	void addedge(const string& a,const string& b);									//������ʶ��ϵ
	void addvertex( node&a);													//������
	int countacquaintance(const string &a);											//ͳ��a��ʶ����
	bool existperson(const string& a);														 //��ѯa�Ƿ����
	bool existrelation(const string& aname,const string& bname);											  //��ѯa,b�Ƿ��й�ϵ
	int size()const;															//ͳ�Ƹ��罻������������
	void showpersonalinfo(const string& aname);												//չʾ������Ϣ	
	void shortestrelationpath(const string& a, const string& b);							 //�������ϵ·��
	void deleteedge(const string& a, const string& b);									//������ʶ��ϵ
	void deletevertex(node&a);
private:
	map<Vertex,node> points;				  //���㼯
	map<string, Vertex>nameid;					//mapָ���˺�id

};



template<class Weight, int graphsize>
void Socialgraph <Weight, graphsize>::addvertex( node &a)						//������
{
	if (existperson(a.name))
	{
		cout << "Already exist!";	return;
	}
	a.id = (this->count)++;
	nameid[a.name] = a.id;
	points[a.id] = a;
	for (int i = 0; i < this->count; i++)
	{
		this->adjacency[a.id][i] = this->adjacency[i][a.id] = infinity;
	}
	this->adjacency[a.id][a.id] = 0;
	cout << "Successfully add!";
}
template<class Weight, int graphsize>
void Socialgraph <Weight, graphsize>::deletevertex(node &a)						//ɾ����
{
	if (!existperson(a.name))
	{
		cout << "the person does not exist!";	return;
	}
	(this->count)--;
	nameid.erase(a.name);
	points.erase(a.id);
	for (int i = 0; i < this->count; i++)
	{
		this->adjacency[a.id][i] = this->adjacency[i][a.id] = infinity;
	}
	cout << "Successfully delete!";
}


template<class Weight, int graphsize>
void Socialgraph <Weight, graphsize>::addedge(const string& a,const string& b)				//������ʶ��ϵ
{
	if (!existperson(a) || !existperson(b))
	{
		cout << "please add the person first!"; return;
	}
	int aid = nameid[a]; int bid = nameid[b];
	if (this->adjacency[aid][bid]==1)
	{
		cout << "Already exist!";	return;
	}
	this->adjacency[aid][bid] = this->adjacency[bid][aid] = 1;
	cout << "Successfully add!";
}

template<class Weight, int graphsize>
void Socialgraph <Weight, graphsize>::deleteedge(const string& a, const string& b)				//ɾ����ʶ��ϵ
{
	if (!existperson(a) || !existperson(b))
	{
		 return;
	}
	int aid = nameid[a]; int bid = nameid[b];
	this->adjacency[aid][bid] = this->adjacency[bid][aid] = infinity;
	cout << "Successfully delete!";
}
template<class Weight, int graphsize>
int Socialgraph <Weight, graphsize>::countacquaintance(const string& a)				  //ͳ��a��ʶ����
{
	if (!existperson(a))
	{
		cout << "please add the person first!"; return 0;
	}
	int xid = nameid[a];
	int res = 0;
	for (int i = 0; i < graphsize; i++)
		if(this->adjacency[xid][i]==1)
			res ++ ;
	return res;
}
template<class Weight, int graphsize>											  //ͳ�Ƹ��罻������������
int Socialgraph <Weight, graphsize>::size()const
{
	return this->count;
}
template<class Weight, int graphsize>											  //��ѯa�Ƿ����
bool Socialgraph <Weight, graphsize>::existperson(const string& a)
{
	if (nameid.find(a) != nameid.end()) return true;
	return false;
}
template<class Weight, int graphsize>											  //��ѯa,b�Ƿ��й�ϵ
bool Socialgraph <Weight, graphsize>::existrelation(const string& aname, const string& bname)
{
	if (!existperson(aname) || !existperson(bname))
	{
		cout << "please add the person first!"; return false;
	}
	int aid = nameid[aname]; int  bid = nameid[bname];
	if (this->adjacency[aid][bid]==1) return true;
	return false;
}
template<class Weight, int graphsize>
void Socialgraph <Weight, graphsize>::showpersonalinfo(const string& xname)				//չʾ������Ϣ
{
	if (!existperson(xname))
	{
		cout << xname<<" does not exist!";	return;
	}
	int xid = nameid[xname];
	cout << "Name: " << points[xid].name << " " << "Age: " << points[xid].age << endl;
}
template<class Weight, int graphsize>
void Socialgraph <Weight, graphsize>::shortestrelationpath(const string& a, const string& b)			//��ѯ��������ͨ����������ϵ
{

	Weight distance[graphsize];	  Vertex lastvertex[graphsize];
	this->setdistance(nameid[a],distance,lastvertex);
	lastvertex[nameid[a]] = -1;
	int res=distance[nameid[b]];
	if (res != infinity)
	{
		cout << "They can be related through at least " << res - 1 << " person.";
		cout << "The path is:";
		Vertex curid = lastvertex[nameid[b]]; stack<Vertex>tmp;
		while (curid != -1)
		{
			tmp.push(curid);
			curid = lastvertex[curid];
		}
		while (!tmp.empty())
		{
			curid = tmp.top();
			cout << points[curid].name<<" ";
			tmp.pop();
		}
		cout << b << endl;
	}	
	else cout << "They cannot be related.";
}


