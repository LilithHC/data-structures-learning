#include<iostream>
#include<algorithm>
using namespace std;

enum Error_code{success,underflow,overflow,range_out,not_present,fail};

template<class List_entry>
class List {
public:
	int kind;					//1 ordered 0 inordered	 
	List_entry *entry;	
	List(int n=10010);
	int size()const;		 //���ر�Ԫ�ظ���
	void clear();			   //���
	bool full()const;			// �ж��Ƿ���
	bool empty()const;			// �п�
	void traverse(void(*visit)(List_entry &));// ��������ÿ��Ԫ�ز���
	Error_code retrieve(int pos, List_entry &x)const;//�ṩ posλ��Ԫ�ظ�x
	Error_code remove(int pos, List_entry &x);		   //  ɾ��posλ��Ԫ��x,ԭλ��Ԫ�ظ���x
	Error_code insert(int pos, const List_entry &x);	 //	����x��posλ��
	Error_code replace(int pos, const List_entry &x);	   //��posλ����Ԫ���滻Ϊx
protected:
	int count;
	int max_list;

};

template<class List_entry>
List<List_entry>::List(int n)
{
	entry = new List_entry[n];
	count = 0;
	kind = 0;
	max_list = n;
}

template<class List_entry>
int List<List_entry>::size()const
{
	return count;
}
template<class List_entry>
void List<List_entry>::clear()
{
	count = 0;
}
template<class List_entry>
bool List<List_entry>::full()const
{
	return count >= max_list;
}
template<class List_entry>
bool List<List_entry>::empty()const
{
	return !count;
}
template<class List_entry>
void List<List_entry>::traverse(void(*visit)(List_entry&))
{
	for (int i = 0; i < count; i++)
	{
		(*visit)(entry[i]);
	}
}
template<class List_entry>
Error_code List<List_entry>::retrieve(int pos, List_entry &x)const
{
	if (pos < 0||pos>= count )
		return range_out;
	else
	{
		x = entry[pos];
		return success;
	}
}
template<class List_entry>
Error_code List<List_entry>::remove(int pos, List_entry &x)
{
	if (pos < 0 || pos >= count)
		return range_out;
	else if (empty())
		return underflow;
	else
	{
		x = entry[pos];
		copy(entry + pos + 1, entry + count, entry + pos);
		count--;
		return success;
	}
}
template<class List_entry>
Error_code List<List_entry>::insert(int pos, const List_entry &x)
{
	if (pos < 0 || pos > count)
		return range_out;
	else if (full())
		return overflow;
	else
	{
		copy_backward(entry + pos, entry + count, entry + count + 1);
		entry[pos] = x;
		count++;
		return success;
	}
}
template<class List_entry>
Error_code List<List_entry>::replace(int pos, const List_entry &x)
{
	if (pos < 0 || pos >= count)
		return range_out;
	else
	{
		entry[pos] = x;
		return success;
	}
}

