#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<map>
#include "Family.h"
using namespace std;

int main()
{
	freopen("family.txt", "r", stdin);
	freopen("out.txt", "w", stdout);
	//freopen("test1.txt", "r", stdin);
	//freopen("out1.txt", "w", stdout);
	Family A;
	int n, m;
	while (scanf("%d %d ", &n, &m) == 2 && n && m)
	{
		A.clear();
		for (int i = 0; i <= n - 1; i++)
		{
			string x;
			getline(cin, x);
			int scnt = 0;
			for (int j = 0; j < x.size(); j++)		 //��¼�ո���
			{
				if (x[j] == ' ') scnt++;
				else break;
			}
			string xx(x, scnt, x.size());	x = xx;		 //�õ������ո������
			A.insert(i, x, scnt);
		}
		A.setancestor();

		for (int i = 0; i < m; i++)
		{
			string x; string kind; string y;
			for (int j = 1; j <= 6; j++)
			{
				string tmp; cin >> tmp;
				if (j == 1) x = tmp;
				else if (j == 4) kind = tmp;
				else if (j == 6) { string yy(tmp, 0, tmp.size() - 1);	y = yy; }		 //ȥ�����.
			}
			cout << A.judge(x,kind,y) << endl;
		}
		cout << endl;
	}

	return 0;
}

