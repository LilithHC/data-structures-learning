

1.为方便使用，程序设计了文件输入输出
family 对应输出out
test1 对应输出out1

2.注释掉freopen代码块，即可在控制台输入输出