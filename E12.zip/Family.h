#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<map>
using namespace std;

struct node {
	string name; int spacecnt;  // ���� �ո����������ǵڼ���	
	node(string x = "", int s = 0) :name(x), spacecnt(s) {}
};
class Family {
public:
	string findparent(int index);		//Ѱ�Ҹ�ĸ
	void clear();		  //��ճ�ʼ��
	void insert(int i, string x, int scnt);			  // ��������
	string judge(const string &x, const string &kind, const string &y);			//�жϳ�����
	void setancestor();		//��¼���ȣ����㴦��
protected:
	node data[1100];
	string ancestorname;
	map<string, int>nameid;
};
void Family::clear()
{
	memset(data, 0, sizeof(data));
	ancestorname = "";
	nameid.clear();
}
string Family::judge(const string &x, const string &kind, const string &y)
{
	string ans = "False";
	if (x == y) ans = "False";
	else if (kind == "ancestor"&&x == ancestorname || kind == "descendant"&&y == ancestorname)	 ans = "True";
	else if (kind == "sibling")
	{
		if (data[nameid[x]].spacecnt != data[nameid[y]].spacecnt)	ans = "False";
		else if (data[nameid[x]].spacecnt == 1) ans = "True";
		else if (findparent(nameid[x]) == findparent(nameid[y]))	ans = "True";
		else ans = "False";
	}
	else if (kind == "child")
	{
		if (x != ancestorname && findparent(nameid[x]) == y)	  ans = "True";
		else ans = "False";
	}
	else if (kind == "parent")
	{
		if (y != ancestorname && x == findparent(nameid[y]))	  ans = "True";
		else ans = "False";
	}
	return ans;
}
void Family::setancestor()
{
	ancestorname = data[0].name;
}
void Family::insert(int i, string x, int scnt)
{
	data[i] = node(x, scnt);
	nameid[x] = i;						  //����x�������е��±���i
}
string Family::findparent(int index)			  //��Բ������ȵģ��Ҹ�ĸ
{
	if (data[index].spacecnt == 1) return ancestorname;
	int curspacecnt = data[index].spacecnt;
	for (int i = index - 1;; i--)
	{
		if (data[i].spacecnt < curspacecnt)  return data[i].name;
	}
}
